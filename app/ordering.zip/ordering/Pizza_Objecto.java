package co.jlabs.ordering;



import java.io.Serializable;

/**
 * Created by Kashyap on 10/13/2015.
 */
public class Pizza_Objecto implements Serializable {
    String obj;
}
