package co.jlabs.ordering.Interface;

/**
 * Created by JLabs on 01/06/16.
 */
public interface PriceTotal {
    void onPriceChange(int position, float value);
}
