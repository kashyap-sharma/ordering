package co.jlabs.ordering.fragmentsInitialiser;

/**
 * Created by JLabs on 06/28/16.
 */
public interface Initialiser {
    void updateName(int i,String name,String address,String contact, String landmark);

}
